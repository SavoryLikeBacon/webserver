to-do-list
==========

A fun exercise in jQuery.  One can add to-do list items which can then be edited, deleted, or checked off.
